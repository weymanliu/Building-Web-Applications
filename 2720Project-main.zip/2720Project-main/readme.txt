# 2720Project
Journey time indicators  
Group 2  
Chan Hon Fung  1155124829  
Liu Kam Nam    1155109652  
Lai Chun Hei   1155143433  
Au Chun Hei    1155125607  
Shea Wing Tung 1155126215  

#Node server start commands
1. Push all the codes into the 2720VM
2. run these code to initializa the node
	```
	npm install
	node server.js
	```  
3. check out http://csci2720-g73.cse.cuhk.edu.hk

And you can register or login to enter the app.


# We have read http://www.cuhk.edu.hk/policy/academichonesty/
